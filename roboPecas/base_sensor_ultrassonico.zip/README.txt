Ultrasonic Sensor Mount by itsbrian on Thingiverse: https://www.thingiverse.com/thing:1104187

Summary:
Ultrasonic sensor mount for your typical ultrasonic sensor shield you can get at your favorite online electronic retailer.I also included the STL file for the ultransonic sensor shield model that I based the mount design from.

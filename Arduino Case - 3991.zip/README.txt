Arduino Case by ytid on Thingiverse: https://www.thingiverse.com/thing:3991

Summary:
3d printable (makerbot etc) arduino case.  Clean up those prototype projects by encasing your arduino in a neat box.Un-tested as of yet due to my makerbot\\\\'s clogged nozzle, currently waiting for MK5 extruder head to ship to be able to test it out and modify it if need be.Allows for easy plugging in of usb cable.  There is a hole at the back of the case which allows for output/feedback wires to be bundled together and covered in heat shrink tubing. 
